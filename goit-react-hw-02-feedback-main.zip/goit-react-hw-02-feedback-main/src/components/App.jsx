import Feedback from "./Feedback";

export const App = () => {
  return (
    <Feedback/>
  );
};
